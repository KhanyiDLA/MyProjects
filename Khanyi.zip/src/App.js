import logo from './logo.jpg';
import './App.css';

function App() {
  return (
    <div className="App container-fuild m-0 p-0">
      <div className="container-fuild w-100 header">
      <img src={logo} className="my-logo m-auto py-3" alt="logo" />
      <h3 className='name'> Khanyisile Dlamini</h3>

      </div>
    <div className="container-fuild body-des">
      <div className='button-theme bg-theme text-white h3 py-3 px-2 my-4 rounded'><b>About Me</b></div>
      <div className="container p-3 m-auto border rounded">
      I am Khanyisile Dlamini from Orange Farm. I have a Postgraduate Diploma in Management( Business Administration) from Wits Business School as well as a Bsc in Biological Sciences from Wits University. I am currently studying a Computer Science degree at Wits University.
I acquired 6 months experience as a Finance Intern at Basix Group as well as 10 months experience as an Operations Support Consultant at Eftsure Africa. I further acquired data management skills. 

I want to be a developer because I developed an Interest in Information Technology. I believe Information Technology is about problem solving and coming up with innovative ideas.  
I have analytical thinking, Problem solving, attention to detail as well as creative thinking skills which I believe are essential for being a successful developer.

      </div>
    </div>
       
     
    </div>
  );
}

export default App;
